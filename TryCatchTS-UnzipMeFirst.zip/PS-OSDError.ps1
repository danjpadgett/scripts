
<#
.SYNOPSIS
OSD Pause on Failure
.DESCRIPTION
Place in your try catch after log copy to throw smsts.log to screen. 
.LINK
https://www.execmgr.net
#>

#Load SCCM TS Environment, Hide TS Progress to see error window.
$TS = New-Object -ComObject "Microsoft.SMS.TSEnvironment"
$T1 = New-Object -ComObject "Microsoft.SMS.TsProgressUI"
$T1.CloseProgressDialog()

#Stop CM Trace Prompting for Default Viewer.
reg add HKCU\SOFTWARE\Microsoft\Trace32 /V "Register File Types" /d 0 /f

#Load Form Code
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null

$SMSTSPackageName = $TS.Value("_SMSTSPackageName")
$OSDComputerName = $TS.Value("OSDComputerName")
$SMSTSLogPath = $TS.Value("_SMSTSLogPath")+"\smsts.log"

#Generate Form Code

[System.Windows.Forms.MessageBox]::Show("TS '$SMSTSPackageName' has failed on '$OSDComputerName'! `nPlease click OK to review logs and report the failure to your SCCM Admin before trying again." , "TS Failure") 

if ($OKButton -eq "OK" ) 
{
cmtrace.exe "$SMSTSLogPath"
$TS.Value("TSFailed") = "true"
} 
else 
{ 
cmtrace.exe "$SMSTSLogPath"
$TS.Value("TSFailed") = "true"
} 
